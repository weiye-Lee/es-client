import{b as A,cR as $,cS as m,bo as i,b$ as d,c9 as y,bt as b,cc as O,d as w,bh as T,cD as E,cf as M,bg as C,c as j,e as S,bx as P,k as h,bm as D,bC as R}from"./index-D7DaIhWh.js";/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var G={align:{type:String,default:"top",validator:function(e){return e?["start","end","center","stretch","baseline","top","middle","bottom"].includes(e):!0}},gutter:{type:[Number,Object,Array],default:0},justify:{type:String,default:"start",validator:function(e){return e?["start","end","center","space-around","space-between"].includes(e):!0}},tag:{type:String,default:"div"}};/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var N=function(e){var n="xs";return e<768?n="xs":e>=768&&e<992?n="sm":e>=992&&e<1200?n="md":e>=1200&&e<1400?n="lg":e>=1400&&e<1880?n="xl":n="xxl",n};function _(){var t=A(N(m?0:window.innerWidth)),e=function(){t.value=N(m?0:window.innerWidth)};return $("resize",e),t}/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */function x(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var c=Object.getOwnPropertySymbols(t);e&&(c=c.filter(function(o){return Object.getOwnPropertyDescriptor(t,o).enumerable})),n.push.apply(n,c)}return n}function g(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?x(Object(n),!0).forEach(function(c){i(t,c,n[c])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):x(Object(n)).forEach(function(c){Object.defineProperty(t,c,Object.getOwnPropertyDescriptor(n,c))})}return t}function I(t,e){var n=e.justify,c=e.align;return[t,i(i({},"".concat(t,"--").concat(n),n),"".concat(t,"--align-").concat(c),c)]}function k(t,e){var n={},c=function(a){return Object.assign(n,{marginLeft:"".concat(a/-2,"px"),marginRight:"".concat(a/-2,"px")})},o=function(a){return Object.assign(n,{rowGap:"".concat(a,"px")})},s={isNumber:function(a){d(a)&&c(a)},isArray:function(a){O(a)&&a.length&&(s.isNumber(a[0]),d(a[1])&&o(a[1]),b(a[0])&&!y(a[0][e])&&c(a[0][e]),b(a[1])&&!y(a[1][e])&&o(a[1][e]))},isObject:function(a){b(a)&&a[e]&&(O(a)&&a.length?(c(a[e][0]),o(a[e][1])):c(a[e]))}};return Object.keys(s).forEach(function(r){s[r](t)}),n}function J(t){return d(t)?"".concat(t," ").concat(t," 0"):/^\d+(\.\d+)?(px|r?em|%)$/.test(t)?"0 0 ".concat(t):t}function L(t,e){var n={},c=function(r){return Object.assign(n,{paddingLeft:"".concat(r/2,"px"),paddingRight:"".concat(r/2,"px")})},o={isNumber:function(r){d(r)&&c(r)},isArray:function(r){O(r)&&r.length&&(d(r[0])&&c(r[0]),b(r[0])&&r[0][e]&&c(r[0][e]))},isObject:function(r){b(r)&&!O(r)&&r[e]&&c(r[e])}};return Object.keys(o).forEach(function(s){o[s](t)}),n}function X(t,e){var n=e.span,c=e.order,o=e.offset,s=e.push,r=e.pull,a=["xs","sm","md","lg","xl","xxl"],u=a.reduce(function(p,f){var v=e[f],l={};return d(v)?l.span=v:b(v)&&(l=v||{}),g(g({},p),{},i(i(i(i(i({},"".concat(t,"-").concat(f,"-").concat(l.span),!y(l.span)),"".concat(t,"-").concat(f,"-order-").concat(l.order),parseInt(l.order,10)>=0),"".concat(t,"-").concat(f,"-offset-").concat(l.offset),parseInt(l.offset,10)>=0),"".concat(t,"-").concat(f,"-push-").concat(l.push),parseInt(l.push,10)>=0),"".concat(t,"-").concat(f,"-pull-").concat(l.pull),parseInt(l.pull,10)>=0))},{});return g(i(i(i(i(i(i({},"".concat(t),!0),"".concat(t,"-").concat(n),!y(n)),"".concat(t,"-order-").concat(c),c),"".concat(t,"-offset-").concat(o),o),"".concat(t,"-push-").concat(s),s),"".concat(t,"-pull-").concat(r),r),u)}/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */function V(t){return typeof t=="function"||Object.prototype.toString.call(t)==="[object Object]"&&!h(t)}var W=w({name:"TRow",props:G,setup:function(e){var n=T(e),c=n.gutter,o=P();E("rowContext",M({gutter:c}));var s=_(),r=C("row"),a=j(function(){return I(r.value,e)}),u=j(function(){return k(e.gutter,s.value)});return function(){var p,f=e.tag;return S(f,{class:a.value,style:u.value},V(p=o("default"))?p:{default:function(){return[p]}})}}});/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var F={flex:{type:[String,Number]},lg:{type:[Number,Object]},md:{type:[Number,Object]},offset:{type:Number,default:0},order:{type:Number,default:0},pull:{type:Number,default:0},push:{type:Number,default:0},sm:{type:[Number,Object]},span:{type:Number},tag:{type:String,default:"div"},xl:{type:[Number,Object]},xs:{type:[Number,Object]},xxl:{type:[Number,Object]}};/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */function K(t){return typeof t=="function"||Object.prototype.toString.call(t)==="[object Object]"&&!h(t)}var U=w({name:"TCol",inject:["rowContext"],props:F,setup:function(e){var n=C("col"),c=P(),o=D("rowContext",Object.create(null)),s=_(),r=j(function(){return X(n.value,e)}),a=j(function(){var u={},p=e.flex;if(p&&(u.flex=J(p)),o){var f=o.gutter;Object.assign(u,L(f,s.value))}return u});return function(){var u,p=e.tag;return S(p,{class:r.value,style:a.value},K(u=c("default"))?u:{default:function(){return[u]}})}}});/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var B=R(W),H=R(U);export{H as C,B as R};
