import{bC as a,dL as o,dM as i}from"./index-D7DaIhWh.js";/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var r=a(o);a(i);export{r as D};
