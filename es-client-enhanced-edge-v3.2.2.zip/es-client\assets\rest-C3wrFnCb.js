import{a4 as j}from"./index-9FzkS_8A.js";function I(g){const r=[],o=g.split(/\n\s*\n/).map(e=>e.trim()).filter(e=>e.length>0);for(const e of o){const i=e.split(`
`).map(s=>s.trim()).filter(s=>!s.startsWith("//"));if(i.length===0)continue;const t=i[0].split(/\s+/);if(t.length<2){console.warn("警告: 跳过无效的请求块:",e);continue}const p=t[0],b=t.slice(1).join(" "),n={method:p,url:b,body:"",headers:{}};let a=1;const h={};for(let s=1;s<i.length;s++){const l=i[s];if(l.includes(":")){const f=l.indexOf(":"),d=l.substring(0,f).trim();h[d]=l.substring(f+1).trim(),a=s+1}else break}Object.keys(h).length>0&&(n.headers=h),n.body=i.slice(a).join(`
`),n.body.trim()===""&&(n.body=void 0),r.push(n)}return r}function P(g){const r=g.split(`
`),o=[],e=/^\s*(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|TRACE)\b/i;for(let t=0;t<r.length;t++)e.test(r[t])&&o.push(t);if(o.length===0)return"";const i=[];for(let t=0;t<o.length;t++){const p=o[t],b=t+1<o.length?o[t+1]:r.length,n=r.slice(p,b);if(n.length===0)continue;const a=n[0].trim().match(e);if(!a)continue;const h=a[1].toUpperCase(),l=n[0].trim().split(/\s+/).slice(1).join(" "),f=[`${h} ${l}`];let d=n.length;for(let c=1;c<n.length;c++){const u=n[c].trim();if(u==="")continue;const L=u.match(/^([^:]+):(.*)$/);if(L){const k=L[1].trim(),x=L[2].trim();f.push(`${k}: ${x}`)}else{d=c;break}}if(d<n.length){const c=n.slice(d).filter(m=>m.trim()!=="");if(c.length>0){const m=c.join(`
`);if(m.trim()!==""){const u=j(m,2);f.push(u)}}}const y=f.join(`
`);y.trim()!==""&&i.push(y)}return i.join(`

`)}export{P as f,I as p};
