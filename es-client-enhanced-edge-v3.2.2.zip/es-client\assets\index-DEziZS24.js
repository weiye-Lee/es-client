import{bC as a,dL as o,dM as i}from"./index-9FzkS_8A.js";/**
 * tdesign v1.17.6
 * (c) 2025 tdesign
 * @license MIT
 */var r=a(o);a(i);export{r as D};
